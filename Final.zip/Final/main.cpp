#include <iostream>
using namespace std;

// App.cpp �����禡�ŧi
void runVehicleApp();

int main() {
    runVehicleApp();
    return 0;
}
